package com.virtusa.selenium.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_02 {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
		driver.get("http://destinationqa.com/radiobuttons-html/");
		
		//click monday button
		List<WebElement> radio = driver.findElements(By.name("groupName"));
		radio.get(0).click();

		//check box
		driver.findElement(By.name("red")).click();
		driver.findElement(By.name("orange")).click();
	}
}

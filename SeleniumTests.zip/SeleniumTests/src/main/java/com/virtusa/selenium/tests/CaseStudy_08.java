package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_08 {

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
        driver.get("http://newtours.demoaut.com/");
        
        driver.findElement(By.name("userName")).sendKeys("mercury");
        driver.findElement(By.name("password")).sendKeys("mercury");
        driver.findElement(By.name("login")).click();
        
        String from = new Select(driver.findElement(By.xpath("//select[@name='fromPort']"))).getFirstSelectedOption().getText();
        String to = new Select(driver.findElement(By.xpath("//select[@name='toPort']"))).getFirstSelectedOption().getText();
        
        if(from.equals(to))
            System.out.println("Same");
        else
            System.out.println("Not Same");
	}
}

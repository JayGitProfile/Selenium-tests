package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Sample {

	public static void main(String[] args) {

		/*WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();*/
		/*WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();*/
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//url
		driver.get("https://in.ebay.com/");
		
		WebElement register = driver.findElement(By.linkText("register"));
		register.click();
	
		WebElement firstname = driver.findElement(By.id("firstname"));
		firstname.sendKeys("Jayakanth");
		
		WebElement lastname=driver.findElement(By.name("lastname"));
		lastname.sendKeys("Srinivasan");
		
		WebElement email=driver.findElement(By.id("email")); //("wide fld regular-text bold-text float-box"));
		email.sendKeys("jaykanth124@gmail.com");
		
		WebElement PASSWORD=driver.findElement(By.id("PASSWORD"));
		PASSWORD.sendKeys("Sayan1234#");
		
		WebElement button= driver.findElement(By.id("ppaFormSbtBtn"));
		button.submit();
	}
}
package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_04 {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
		driver.get("https://in.ebay.com/");
		
		WebElement registerLink = driver.findElement(By.linkText("register"));
		String href = registerLink.getAttribute("href");
		String _sp = registerLink.getAttribute("_sp");
		
		System.out.println("href attribute: "+href+"\n_sp attribute: "+_sp);
	}
}

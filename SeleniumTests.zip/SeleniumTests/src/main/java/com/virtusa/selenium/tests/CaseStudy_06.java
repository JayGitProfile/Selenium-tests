package com.virtusa.selenium.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_06 {

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
		driver.get("https://www.amazon.in/");
		
		//search box
		WebElement searchBox = driver.findElement(By.name("field-keywords"));
		searchBox.sendKeys("Da Vinci Books");
		
		//search button
		driver.findElement(By.className("nav-input")).submit();
		
		//list of book names and price
		List<WebElement> name = driver.findElements(By.className("a-size-medium"));
        List<WebElement> price = driver.findElements(By.className("a-price-whole"));
     
        for(int i=0;i<name.size();i++) 
        {
        	System.out.println(name.get(i).getText()+"\t"+price.get(i).getText()); 
        }
	}

}

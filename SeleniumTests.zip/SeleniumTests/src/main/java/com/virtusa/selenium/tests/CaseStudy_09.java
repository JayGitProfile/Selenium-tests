package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_09 {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("http://www.newtours.demoaut.com/");
		
		//dimensions
		int unameHeight = driver.findElement(By.name("userName")).getSize().getHeight();
		int passwordHeight = driver.findElement(By.name("password")).getSize().getHeight();
		
		int unameWidth = driver.findElement(By.name("userName")).getSize().getWidth();
		int passwordWidth = driver.findElement(By.name("password")).getSize().getWidth();
		
		if(unameHeight==passwordHeight && unameWidth==passwordWidth)
			System.out.println("Dimensions are equal");
		else
			System.out.println("Dimensions are not equal");

	}

}

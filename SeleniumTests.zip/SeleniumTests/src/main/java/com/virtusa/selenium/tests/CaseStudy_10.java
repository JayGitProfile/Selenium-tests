package com.virtusa.selenium.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_10 {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//url
		driver.get("http://www.google.com/");
        WebElement search=driver.findElement(By.name("q"));
        search.sendKeys("chandraayan");
        WebDriverWait wait = new WebDriverWait(driver,10);
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> suggestions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        for (WebElement webElement : suggestions) 
        {
            System.out.println(webElement.getText());
        }
	}

}

package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_07 {
	public static void main( String[] args )
    {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
		driver.get("http://newtours.demoaut.com/");
        
        driver.findElement(By.name("userName")).sendKeys("mercury");
        driver.findElement(By.name("password")).sendKeys("mercury");
        driver.findElement(By.name("login")).click(); 
        
        //4 passengers
        Select passengers = new Select(driver.findElement(By.name("passCount")));
        passengers.selectByIndex(3);
        
        //departure
        Select departure= new Select(driver.findElement(By.name("fromPort")));
        departure.selectByValue("London");
        Select fromMonth= new Select(driver.findElement(By.name("fromMonth")));
        fromMonth.selectByValue("5");
        Select fromDay= new Select(driver.findElement(By.name("fromDay")));
        fromDay.selectByValue("17");
        
        //arrival
        Select arrival = new Select(driver.findElement(By.name("toPort")));
        arrival.selectByVisibleText("Portland");
        Select toMonth = new Select(driver.findElement(By.name("toMonth")));
        toMonth.selectByVisibleText("September");
        Select toDay = new Select(driver.findElement(By.name("toDay")));
        toDay.selectByVisibleText("21");
        
        driver.findElement(By.name("findFlights")).click(); 
    }
}
package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_01_1 {
	public static void main(String [] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//url
		driver.get("https://www.amazon.com/");
		//register link
		driver.findElement(By.linkText("Start here.")).click();
		
		WebElement name = driver.findElement(By.name("customerName"));
		WebElement email = driver.findElement(By.id("ap_email"));
		//WebElement password = driver.findElement(By.className("a-input-text a-form-normal a-span12 auth-required-field auth-require-fields-match auth-require-password-validation"));
		WebElement password = driver.findElement(By.name("password"));
		WebElement rePswd = driver.findElement(By.name("passwordCheck"));
		//enter data in the fields
		name.sendKeys("Jay");
		email.sendKeys("jay@gmail.com");
		password.sendKeys("heads/3770");
		rePswd.sendKeys("heads/3770");
		
		if(password.getText().equals(rePswd.getText()))
		{
			System.out.println("Password fields match!");
		}
		else
		{
			System.out.println("Password fields do not match!");
		}
	}
}

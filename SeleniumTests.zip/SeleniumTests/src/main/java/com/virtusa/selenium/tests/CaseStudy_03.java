package com.virtusa.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CaseStudy_03 {

	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//url
		driver.get("https://www.rediff.com");
		
		//home page title
        String homeTile = driver.getTitle();
        System.out.println("Home page title: "+homeTile);
        
        //click sign in
        driver.findElement(By.className("signin")).click();
        
        //login page title
        String loginTitle = driver.getTitle();
        System.out.println("Login page title: "+loginTitle);
        
        //navigate back
        driver.navigate().back();
        
        //title check
        String homeBack = driver.getTitle();
        driver.navigate().forward();
        String loginBack = driver.getTitle();
      
        if(homeTile.equals(homeBack))
        {
        	System.out.println("Same page title as home page");
        }
        
        if(loginTitle.equals(loginBack))
        {
        	System.out.println("Same page title as login page");
        }
        
        driver.close();
        driver.quit();
	}

}
